# Curso de Dart - Fernando Herrera

Este es el repositorio usado en la sección 10, también es un ejemplo de cómo se deben de subir los repositorios de Dart a GitHub y mantener su control de versiones. Incluyendo los archivos que debemos o que podemos ignorar.
