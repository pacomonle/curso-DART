/**
 * Este archivo sirve para explicar los comentarios
 * 
 *  [creadoEn] : Hoy
 */

///
///
///
///

main() {

  // Esta es una variable temporal que quiero definir
  int a = 10; // A debería de ser 10

  /*
  final personas = [
    // Esta es la primera persona
    'Fernando', // [0]

    // Esta es la segunda persona
    'Pedro', // [1]

    // Esta es la tercera persona
    'Carlos' // [2]

  ];
  */

}

// Nombre: El nombre de la persona que quiero saludar
// Mensaje:  Es el saludo que quiero hacer


/// Funciona para saludar
/// Recibe un [nombre] y se concatena con el [mensaje]
saludar( int nombre, int mensaje ) {}

