

void main() {

  var mensaje = saludar();

  print(mensaje);

}


String saludar() {

  return 'Hola Fernando';

}